/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package td_poo;

/**
 *
 * @author anani
 */
public class TD_POO {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        double[] solde_compte = {20000,150000,72700};
        Personne p1 = new Personne("Coupedrix", 25,
                solde_compte);
        p1.afficher();
        p1.diviserParDeux();
        Personne p2 = new Personne();
        p2.setNom("jackes");
        p2.setAge(29);
        p2.setComptes(new double[]{12000,34000,23000,234000});
        p2.afficher();
        p2.diviserParDeux();
        Personne p3 = new Personne(p1);
    }
    
}
