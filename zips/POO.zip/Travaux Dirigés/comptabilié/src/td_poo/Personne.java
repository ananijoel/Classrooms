/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package td_poo;

/**
 *
 * @author anani
 */
public class Personne {
    private String nom;
    private int age;
    private double[] comptes;
    //Constructeurs
    public Personne(){
        
    }
    public Personne(String leNom, int lAge, double[] mesComptes){
        this.nom = leNom;
        this.age = lAge;
        this.comptes = mesComptes;
    }
    public Personne(Personne p){
        this.nom = p.getNom();
        this.age = p.getAge();
        this.comptes = p.comptes;
    }
    //getters
    public String getNom(){
        return nom;
    }
    public int getAge(){
        return age;
    }
    public double[] getComptes(){
        return comptes;
    }
    //setters
    public void setNom(String leNom){
        this.nom = leNom;
    }
    public void setAge(int lAge){
        this.age = lAge;
    }
    public void setComptes(double[] comptes){
        this.comptes = comptes;
    }
    
    public void afficher(){
         System.out.println("Mon nom est : "+nom+" et mon age est : "+age+" ans.");
         System.out.println("Voici la liste de mes comptes : ");
         for (double compte : comptes) {
             System.out.println(compte);
        }
    }
    public void diviserParDeux(){
        System.out.println("Division des soldes par 2 : ");
        for (double compte : comptes) {
            System.out.println(compte/2);
        }
    }
}   
