/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bibliotheque;

import java.util.Scanner;

/**
 * @author anani
 */

public class LivrePoche {
    String titre;
    String nom_de_l_auteur;
    String prenom_de_l_auteur;
    String ISBN;

    public LivrePoche() {
    }

    public LivrePoche(String titre, String nom_de_l_auteur, String prenom_de_l_auteur, String ISBN) {
        this.titre = titre;
        this.nom_de_l_auteur = nom_de_l_auteur;
        this.prenom_de_l_auteur = prenom_de_l_auteur;
        this.ISBN = ISBN;
    }

    public void Definition_LivrePoche() {
        Scanner sc = new Scanner(System.in);
        System.out.print("Entrez le titre du livre : ");
        this.titre = sc.nextLine();

        System.out.print("Entrez le nom de l'auteur de " + this.titre + ": ");
        this.nom_de_l_auteur = sc.nextLine();

        System.out.print("Entrez le prenom de l'auteur de  " + this.titre + "  : ");
        this.prenom_de_l_auteur = sc.nextLine();
        System.out.print("Entrez  l'ISBN de: " + this.titre + " : ");
        this.ISBN = sc.nextLine();
        /*
        while (this.ISBN.getClass().getSimpleName() != "Float" && String.valueOf(this.ISBN).length() <10 &&  String.valueOf(this.ISBN).length() >13){
            if()
        }
         */
    }

    public void affichage_LivrePoche() {
        System.out.println("------------------------------------------");
        System.out.println("------------------------------------------");
        System.out.println("titre : " + this.titre +
                "\nnom de l'auteur : " + this.nom_de_l_auteur +
                "\nprenom de l'auteur : " + this.prenom_de_l_auteur +
                "\ncode ISBN du livre: " + this.ISBN + "\n");
    }

}
