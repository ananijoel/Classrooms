Programme visant a explorer la creation de classes, d'attributs, de methodes, de getters et de setters.
L'objet cree et manipulé ici est un point dans un plan.