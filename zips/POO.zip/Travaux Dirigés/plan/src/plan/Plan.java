/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package plan;

import plan.friendly.Test1;

/**
 *
 * @author anani
 */
public class Plan {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Test1 t1 = new Test1();
        t1.salutation();
        t1.salutation("Marie");
        t1.salutation("madame", "Marie");
        /*
        Point p1 = new Point();
        p1.DefinirPoint();
        System.out.println(p1.toString());
        Point p2 = new Point();
        p2.DefinirPoint();
        System.out.println(p2.toString());
        double distance = p1.distance(p2);
        System.out.println("la distance entre les deux points est : "+distance);       */
}
    
}
