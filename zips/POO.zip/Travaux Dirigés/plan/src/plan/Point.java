/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package plan;

import java.util.Scanner;

/**
 *
 * @author anani
 */
public class Point {
    private double positionX;
    private double positionY;

    public Point() {

    }

    // constructeur
    public Point(double positionX, double positionY) {
        this.positionX = positionX;
        this.positionY = positionY;
    }

    //setter
    public void setPositionX(double positionX) {
        this.positionX = positionX;
    }

    public void setPositionY(double positionY) {
        this.positionX = positionY;
    }

    //getter
    public double getPositionX() {
        return positionX;
    }

    public double getPositionY() {
        return positionY;
    }

    public void DefinirPoint(){
        Scanner sc = new Scanner(System.in);
        System.out.print("Entrez la coordonnee x du point : ");
        this.positionX = sc.nextDouble();
        System.out.print("Entrez la coordonnee y du point : ");
        this.positionY = sc.nextDouble();
    }

    public String toString() {
        return "P(" + positionX + "," + positionY + ")";
    }

    /*public double distance(double objectpositionX, double objectpositionY) {
        double distance;
        return  distance = Math.sqrt(Math.pow((this.positionX - objectpositionX), 2) + Math.pow((this.positionY - objectpositionY), 2));

    } */
    public double distance(Point p2) {
        return  Math.sqrt(Math.pow((this.positionX - p2.getPositionX()), 2) + Math.pow((this.positionY - p2.getPositionY()), 2));

}
    public double distance2(Point p1,Point p2) {
        return  Math.sqrt(Math.pow((p1.positionX - p2.positionX), 2) + Math.pow((p1.positionY - p2.positionY), 2));
    }

}
