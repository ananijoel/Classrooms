/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package td_exception;

import java.text.DateFormatSymbols;
import java.util.Scanner;

/**
 *
 * @author anani
 */
public class ExempleException {
    private int firstNumer;
    private int secondNumber;
    private String monthString;
    Scanner sc = new Scanner(System.in);
    
    public ExempleException(){
        
    }
    public ExempleException(int firstNumer, int secondNumber){
        this.firstNumer = firstNumer;
        this.secondNumber = secondNumber;
    }
    public void  euclideanDivider(){
        System.out.println("Veuillez entrer le premier nombre");
        firstNumer = sc.nextInt();
        System.out.println("Veuillez entrer le second nombre");
        secondNumber = sc.nextInt();
        try{
           System.out.println(firstNumer/secondNumber);  
        }catch(ArithmeticException e){
            System.err.println("erreur le denominateur ne doit pas etre null");
        }
         
    }
    public void  numberToMonth() throws IndexOutOfBoundsException{ 
            int monthNumber;
            System.out.println("Entrez un nombre entre 1 et 12");
            monthNumber = sc.nextInt();
            //monthString = new DateFormatSymbols().getMonths()[monthNumber];
            if(monthNumber<1 || monthNumber>12){
                throw new IndexOutOfBoundsException("le numero de mois doit etre compris entre 1 et 12.");
            }
            switch (monthNumber ) {
            case 1:  monthString = "January";       break;
            case 2:  monthString = "February";      break;
            case 3:  monthString = "March";         break;
            case 4:  monthString = "April";         break;
            case 5:  monthString = "May";           break;
            case 6:  monthString = "June";          break;
            case 7:  monthString = "July";          break;
            case 8:  monthString = "August";        break;
            case 9:  monthString = "September";     break;
            case 10: monthString = "October";       break;
            case 11: monthString = "November";      break;
            case 12: monthString = "December";      break;
        }
        System.out.println(monthString);
    }
    
}
