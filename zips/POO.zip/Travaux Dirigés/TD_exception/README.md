Ce projet illustre les concepts de base de la gestion des exceptions en Java, y compris les blocs try-catch, les blocs finally, et les exceptions personnalisées. 
