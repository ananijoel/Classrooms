/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package td1;

/**
 *
 * @author Joel
 */
public class Rectangle {
    //Déclaration des attributs
     private double longueur;
     private double largeur;
 
//Creation du constructeur par défaut
public Rectangle(){
}
//Création d'un constructeur paramétré
public Rectangle(double L, double l){
    this.longueur = L;
    this.largeur = l;
}
//Création d'un constructeur par recopie
public Rectangle(Rectangle r){
this.longueur = r.longueur;
this.largeur = r.largeur;
}
//accesseur(getter)
public double getLongueur(){
    return longueur;
}

public double getLargeur(){
    return largeur;
}
//Mutateurs(setter)
public void setLongueur(double longueur){
    this.longueur = longueur;
}
public void setLargeur(double largeur){
    this.largeur = largeur; 
}
 //Méthode démi-périmetre   
public double demiPerimetre()
{ 
    return longueur + largeur;       
}
//Méthode périmetre
public double perimetre(){
    return demiPerimetre()*2;
}
//Méthode aire
public double aire(){
    return longueur * largeur;
}
//creation de la methode toString

    @Override
    public String toString() {
        return "Rectangle : longueur = "+longueur+" ; largeur = "+largeur; 
    }



}


 

