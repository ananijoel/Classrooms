/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package td1;

/**
 *
 * @author Joel
 */
public class TD1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // Creation de l'objet rectangle1
        Rectangle r1 = new Rectangle();
        r1.setLongueur(10);
        r1.setLargeur(5);

        System.out.println(r1.toString());
        System.out.println("Le démi-périmetre est : "+r1.demiPerimetre());
        System.out.println("Le périmetre est : "+r1.perimetre());
        System.out.println("L'aire est : "+r1.aire());

        Rectangle r2 = new Rectangle(15, 7);
        System.out.println("");
        System.out.println("");
        System.out.println("INFORMATIONS DE L'OBJET R2");
        System.out.println(r2.toString());
        System.out.println("Le démi-périmetre est : "+r2.demiPerimetre());
        System.out.println("Le périmetre est : "+r2.perimetre());
        System.out.println("L'aire est : "+r2.aire());
        
        Rectangle r3 = new Rectangle(r1);
        System.out.println("");
        System.out.println("");
        System.out.println("INFORMATIONS DE L'OBJET R3");
        System.out.println(r3.toString());
        System.out.println("Le démi-périmetre est : "+r3.demiPerimetre());
        System.out.println("Le périmetre est : "+r3.perimetre());
        System.out.println("L'aire est : "+r3.aire());    
    }
    
    
}
