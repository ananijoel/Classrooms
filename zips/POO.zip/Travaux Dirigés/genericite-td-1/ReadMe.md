Programme visant a explorer le concept de généricité a un seul type de variable par classe
L'objet crée ici est un triplet de valeurs