/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package genericite.td.pkg1;


/**
 *
 * @author anani
 */
public class GenericiteTd1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
         
        Triplet <String> Tstring = new Triplet<>("malenia","raddahn","godfrey");
        System.out.println("Premier : "+Tstring.getPremier()+", Second : "+Tstring.getSecond()+", Troisieme : "+Tstring.getTroisieme());
        System.out.println(Tstring.afficher());
    }
    
}
