/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package genericite.td.pkg1;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author anani
 */
public class Triplet<T> {
        private T premier;
        private T second;
        private T troisieme;
        public Triplet (){
            
        }
        public Triplet (T premier, T second, T troisieme){
            this.premier = premier;
            this.second = second;
            this.troisieme = troisieme;
            
        }
        //getters
        public T getPremier(){
            return premier;
        }
        public T getSecond(){
            return second;
        }
        public T getTroisieme(){
            return troisieme;
        }
        
        public String afficher(){
            return "\nPremier : "+premier+",\nSecond : "+second+",\nTroisieme : "+troisieme+"";
        }
        
}
