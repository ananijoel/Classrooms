Programme visant a explorer le concept de généricité a un plusieurs types de variables par classe
L'objet crée ici est un triplet de valeurs