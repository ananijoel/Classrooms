/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package genericite.td.pkg1;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author anani
 */
public class GenericiteTd1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
         
        Triplet < Integer,String,Integer > Tstring = new Triplet<>(1,"malenia",2);
        System.out.println("Premier : "+Tstring.getPremier()+", Second : "+Tstring.getSecond()+", Troisieme : "+Tstring.getTroisieme());
        System.out.println(Tstring.afficher());
    }
    
}
