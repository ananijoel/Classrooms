/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package genericite.td.pkg1;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author anani
 */
public class Triplet<T,U,V> {
        private T premier;
        private U second;
        private V troisieme;
        public Triplet (){
            
        }
        public Triplet (T premier, U second, V troisieme){
            this.premier = premier;
            this.second = second;
            this.troisieme = troisieme;
            
        }
        //getters
        public T getPremier(){
            return premier;
        }
        public U getSecond(){
            return second;
        }
        public V getTroisieme(){
            return troisieme;
        }
        
        public String afficher(){
            return "\nPremier : "+premier+",\nSecond : "+second+",\nTroisieme : "+troisieme;
        }
        
}
