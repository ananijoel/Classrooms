/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package tp.etudiant;

import java.time.LocalDate;
import java.util.Scanner;

/**
 *
 * @author anani anatide
 */
public class TPEtudiant {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //creation d'un objet avec le constructeur par defaut
        Etudiant E1 = new Etudiant();
        E1.matricule = "A10036";
        E1.nom = "Adjovi";
        E1.prenom = "deto";
        E1.dateDeNaissance = LocalDate.of(2002, 9, 30);
        E1.filiere = "SR";
        //creation d'un objet avec le constructeur parametre
        Etudiant E2 = new Etudiant("B21147", "Komi", "Gregoire",
                        LocalDate.of(2000, 6, 13),
                                    "GL");
        //System.out.println(E1);
        //System.out.println(E2);
        System.out.println("Informations de l'etudiant 1");
        E1.affichage();
        System.out.println("Informations de l'etudiant 2");
        E2.affichage();
        //Saisie des informations au clavier
        //creation d'un objet de la classe Scanner
        Scanner sc = new Scanner(System.in);
        
        System.out.println("Entrez votre matricule : ");
        String matricule = sc.nextLine();
        
        System.out.println("Entrez votre Nom : ");
        String nom = sc.nextLine();
        
        System.out.println("Entrez votre Prenom : ");
        String prenom = sc.nextLine();
        
        //System.out.println("Entrez votre Date de naissance : ");
        //String dateDeNaissance = sc.nextLine();
        LocalDate dateDeNaissance = LocalDate.of(2005, 12, 25);
        
        System.out.println("Entrez votre filiere : ");
        String filiere = sc.nextLine();
        
        Etudiant E3 = new Etudiant(matricule, nom, prenom, dateDeNaissance, filiere);
         E3.affichage();
    }
    
}
