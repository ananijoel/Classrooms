    /*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tp.etudiant;

import java.time.LocalDate;

/**
 *
 * @author anani anatide
 */
public class Etudiant {
    String matricule;
    String nom;
    String prenom;
    LocalDate dateDeNaissance;
    String filiere;
    
    public Etudiant(){}
    
    public Etudiant(String matricule,String nom,String prenom,LocalDate dateDeNaissance,String filiere){
        this.matricule = matricule;
        this.nom = nom;
        this.prenom = prenom;
        this.dateDeNaissance = dateDeNaissance;
        this.filiere = filiere;
    }

    @Override
    public String toString() {
        return "Etudiant{" + "matricule=" + matricule + ", nom=" + nom + ", prenom=" + prenom + ", dateDeNaissance=" + dateDeNaissance + ", filiere=" + filiere + '}';
    }
    
    public void affichage(){
        System.out.println("Matricule : "+matricule+
                           "\nNom : "+nom+
                           "\nPrenom : "+prenom+
                           "\nDate de naissance : "+dateDeNaissance+
                           "\nFiliere : "+filiere+"\n");
        

    }
}
